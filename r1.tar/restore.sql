--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.2
-- Dumped by pg_dump version 14.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE railway_final;
--
-- Name: railway_final; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE railway_final WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_India.1252';


ALTER DATABASE railway_final OWNER TO postgres;

\connect railway_final

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: assign_seat(integer, date, character varying, integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.assign_seat(t_no integer, dod date, p_class character varying, src integer, dest integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
declare seat integer;
begin
    seat:=0;
    if exists (select seat_no from availability,schedule where s_no = schedule_no
    and  schedule.train_no = t_no and schedule.date_of_departure = dod and 
    true = all(available_arr[src:dest-1]) and class = p_class ) then
    begin
        select seat_no from availability,schedule 
        into seat where s_no = schedule_no 
        and  schedule.train_no = t_no and schedule.date_of_departure = dod and 
        true = all(available_arr[src:dest-1]) and class = p_class 
        order by seat_no limit 1; 
    end;
    end if;
    return seat;
end;
$$;


ALTER FUNCTION public.assign_seat(t_no integer, dod date, p_class character varying, src integer, dest integer) OWNER TO postgres;

--
-- Name: book(integer, integer, date); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.book(IN uid integer, IN t_no integer, IN dod date)
    LANGUAGE plpgsql
    AS $$
begin
insert into booking(booking_time,booked_by,train_no,date_of_departure) values(LOCALTIMESTAMP(0),uid,t_no,dod);
create or replace view curr_booking as select * from booking order by booking_time desc limit 1;
end;
$$;


ALTER PROCEDURE public.book(IN uid integer, IN t_no integer, IN dod date) OWNER TO postgres;

--
-- Name: book_ticket(character varying, character varying, character varying, integer, character varying, integer, character varying, character varying, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.book_ticket(IN f_name character varying, IN l_name character varying, IN gender character varying, IN age integer, IN p_class character varying, IN pnr integer, IN category character varying, IN src character varying, IN dest character varying)
    LANGUAGE plpgsql
    AS $$
    declare p_id integer;
    declare seat_no integer;
    declare t_no integer;
    declare dod date;
    declare dest_order integer;
    declare src_order integer;
begin
    insert into passengers(first_name,last_name,gender,age) values(f_name,l_name,gender,age);
    select max(passenger_id) from passengers into p_id;
    select train_no from booking into t_no where pnr_number = pnr;
    select date_of_departure from booking into dod where pnr_number = pnr;
    select "order" from route into src_order where train_no = t_no and station_name = src;
    select "order" from route into dest_order where train_no = t_no and station_name = dest;
    select * from assign_seat(t_no,dod,p_class,src_order,dest_order) into seat_no;
    raise notice '%', seat_no;
    if (seat_no != 0) then 
        insert into ticket values(p_id,p_class,compute_fare(p_class,category,src_order,dest_order),seat_no,'Confirmed',pnr,category,src,dest);
    else 
        insert into ticket values(p_id,p_class,compute_fare(p_class,category,src_order,dest_order),seat_no,'Waiting List',pnr,category,src,dest);  
    end if; 
end;
$$;


ALTER PROCEDURE public.book_ticket(IN f_name character varying, IN l_name character varying, IN gender character varying, IN age integer, IN p_class character varying, IN pnr integer, IN category character varying, IN src character varying, IN dest character varying) OWNER TO postgres;

--
-- Name: cancel(integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.cancel(IN pnr integer)
    LANGUAGE plpgsql
    AS $$
begin
    delete from ticket where pnr_number = pnr;
    delete from booking where pnr_number = pnr;
end;
$$;


ALTER PROCEDURE public.cancel(IN pnr integer) OWNER TO postgres;

--
-- Name: compute_fare(character varying, character varying, integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.compute_fare(class character varying, category character varying, src_order integer, dest_order integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
declare fare integer;
begin
    fare:=200;
    if(class = 'AC') then fare:=fare*2;
    end if;
    if(category = 'Tatkal') then fare:=fare*1.5;
    elsif(category = 'Ladies') then fare:=fare*0.7;
    elsif(category = 'Senior') then fare:=fare*0.5;
    end if;
    fare:=fare*(dest_order-src_order);
    return fare;
end;
$$;


ALTER FUNCTION public.compute_fare(class character varying, category character varying, src_order integer, dest_order integer) OWNER TO postgres;

--
-- Name: delete_passenger(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.delete_passenger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
    delete from passengers where passenger_id = old.passenger_id;
    return old;
end;
$$;


ALTER FUNCTION public.delete_passenger() OWNER TO postgres;

--
-- Name: free_avail(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.free_avail() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare 
	src_order integer;
	dest_order integer;
	f_name varchar;
	l_name varchar;
	ge varchar;
	old_src varchar;
	old_dest varchar;
	p_class varchar;
    cat varchar;
	ag integer;
	pnr integer;
    p_id integer;
    t_no integer;
begin
	pnr:=-1;
    select "order", station_name from route,booking into src_order, old_src where booking.pnr_number = old.pnr_number and
    route.train_no=booking.train_no and station_name = old.src;
    select "order", station_name,booking.train_no from route,booking into dest_order, old_dest,t_no where booking.pnr_number = old.pnr_number and
    route.train_no=booking.train_no and station_name = old.dest;

    if old.seat_no != 0 then
		update availability set available_arr[src_order:dest_order-1] = array_fill(true,ARRAY[dest_order-src_order]) from schedule,booking 
		where seat_no = old.seat_no and class = old.passenger_class 
		and s_no = schedule_no and booking.pnr_number = old.pnr_number and 
		schedule.train_no = booking.train_no and schedule.date_of_departure = booking.date_of_departure;

        select ticket.pnr_number,passengers.passenger_id
        into pnr,p_id
		from ticket, passengers,booking
	    where ticket.seat_no = 0 and passengers.passenger_id = ticket.passenger_id
        and booking.pnr_number = ticket.pnr_number and booking.train_no = t_no
		and ticket.src = old.src and ticket.dest = old.dest limit 1;
        raise notice 'pnr % pid %',pnr,p_id;
		if(pnr>0)	then
			update ticket set reservation_status = 'Confirmed', seat_no = old.seat_no 
            where passenger_id = p_id;
            update availability set available_arr[src_order:dest_order-1] = array_fill(false,ARRAY[dest_order-src_order]) from schedule,booking 
            where seat_no = old.seat_no and class = old.passenger_class 
            and s_no = schedule_no and booking.pnr_number = old.pnr_number and 
            schedule.train_no = booking.train_no and schedule.date_of_departure = booking.date_of_departure;
		end if;
    end if;
    return old;
end;

$$;


ALTER FUNCTION public.free_avail() OWNER TO postgres;

--
-- Name: login(integer, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.login(uid integer, pwd character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
begin
if (uid in (select user_id from "user")) then
		if (pwd in (select password from "user" where user_id = uid)) then
			raise info 'Login Successful';
			return true;
		else
			raise info 'Incorrect Password';
			return false;
		end if;
else
	raise info 'Invalid User';
	return false;
end if;
end;
$$;


ALTER FUNCTION public.login(uid integer, pwd character varying) OWNER TO postgres;

--
-- Name: max_order(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.max_order(t_no integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
declare mx integer;
begin
    --Get the order from route table
    select COALESCE(max("order"),2) from route into mx where train_no=t_no;

    return mx;
end;
$$;


ALTER FUNCTION public.max_order(t_no integer) OWNER TO postgres;

--
-- Name: passenger_details(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.passenger_details(pnr integer) RETURNS TABLE(first_name character varying, last_name character varying, age integer, gender character varying, passenger_class character varying, fare integer, seat_no integer, reservation_status character varying, "from" character varying, "to" character varying)
    LANGUAGE plpgsql
    AS $$
begin
	return query
		select passengers.first_name, passengers.last_name, passengers.age, passengers.gender, 
		ticket.passenger_class, ticket.fare, ticket.seat_no, ticket.reservation_status, 
		train.src as "From", train.dest as "To"
		from passengers,ticket,booking,train
		where ticket.pnr_number = pnr
		and passengers.passenger_id = ticket.passenger_id and ticket.pnr_number = booking.pnr_number and 
		booking.train_no = train.train_no;
end;
$$;


ALTER FUNCTION public.passenger_details(pnr integer) OWNER TO postgres;

--
-- Name: set_avail(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.set_avail() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare src_order integer;
declare dest_order integer;
begin
    select "order" from route,booking into src_order where booking.pnr_number = new.pnr_number and
    route.train_no=booking.train_no and station_name = new.src;
    select "order" from route,booking into dest_order where booking.pnr_number = new.pnr_number and
    route.train_no=booking.train_no and station_name = new.dest;

    if new.seat_no != 0 then
    update availability set available_arr[src_order:dest_order-1]=array_fill(false,ARRAY[dest_order-src_order]) from schedule,booking 
    where seat_no = new.seat_no and class = new.passenger_class and
    s_no = schedule_no and booking.pnr_number = new.pnr_number and 
    schedule.train_no = booking.train_no and schedule.date_of_departure = booking.date_of_departure;
    end if;
    return new;
end;
$$;


ALTER FUNCTION public.set_avail() OWNER TO postgres;

--
-- Name: trainlist(character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.trainlist(sc character varying, dst character varying) RETURNS TABLE(source_station character varying, destination_station character varying, train_name character varying, train_number integer, departure_time time without time zone, arrival_time time without time zone, date_of_departure date)
    LANGUAGE plpgsql
    AS $$
begin
	return query
		select r1.station_name, r2.station_name, train.train_name, train.train_no, 
		train.departure_time, train.arrival_time, schedule.date_of_departure
		from route as r1, route as r2, train, schedule
		where train.train_no = schedule.train_no 
        and r1.station_name = sc and r2.station_name = dst 
        and r1.train_no = train.train_no and r2.train_no = train.train_no;
end;
$$;


ALTER FUNCTION public.trainlist(sc character varying, dst character varying) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: availability; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.availability (
    s_no integer NOT NULL,
    seat_no integer NOT NULL,
    class character varying NOT NULL,
    available_arr boolean[] NOT NULL
);


ALTER TABLE public.availability OWNER TO postgres;

--
-- Name: booking; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.booking (
    booked_by integer NOT NULL,
    train_no integer NOT NULL,
    pnr_number integer NOT NULL,
    booking_time timestamp without time zone NOT NULL,
    date_of_departure date NOT NULL
);


ALTER TABLE public.booking OWNER TO postgres;

--
-- Name: booking_pnr_number_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.booking_pnr_number_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.booking_pnr_number_seq OWNER TO postgres;

--
-- Name: booking_pnr_number_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.booking_pnr_number_seq OWNED BY public.booking.pnr_number;


--
-- Name: curr_booking; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.curr_booking AS
 SELECT booking.booked_by,
    booking.train_no,
    booking.pnr_number,
    booking.booking_time,
    booking.date_of_departure
   FROM public.booking
  ORDER BY booking.booking_time DESC
 LIMIT 1;


ALTER TABLE public.curr_booking OWNER TO postgres;

--
-- Name: passengers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.passengers (
    passenger_id integer NOT NULL,
    first_name character varying(45) NOT NULL,
    last_name character varying(45),
    gender character varying(45) NOT NULL,
    age integer NOT NULL,
    CONSTRAINT age_check CHECK ((age > 0)),
    CONSTRAINT gender_check CHECK (((gender)::text = ANY (ARRAY[('Male'::character varying)::text, ('Female'::character varying)::text, ('Other'::character varying)::text])))
);


ALTER TABLE public.passengers OWNER TO postgres;

--
-- Name: passengers_passenger_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.passengers_passenger_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.passengers_passenger_id_seq OWNER TO postgres;

--
-- Name: passengers_passenger_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.passengers_passenger_id_seq OWNED BY public.passengers.passenger_id;


--
-- Name: route; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.route (
    train_no integer NOT NULL,
    "order" integer NOT NULL,
    station_name character varying NOT NULL
);


ALTER TABLE public.route OWNER TO postgres;

--
-- Name: schedule; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.schedule (
    train_no integer NOT NULL,
    schedule_no integer NOT NULL,
    date_of_departure date NOT NULL,
    date_of_arrival date NOT NULL
);


ALTER TABLE public.schedule OWNER TO postgres;

--
-- Name: ticket; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ticket (
    passenger_id integer NOT NULL,
    passenger_class character varying(45) DEFAULT 'General'::character varying NOT NULL,
    fare integer NOT NULL,
    seat_no integer,
    reservation_status character varying(45) NOT NULL,
    pnr_number integer NOT NULL,
    category character varying,
    src character varying NOT NULL,
    dest character varying NOT NULL
);


ALTER TABLE public.ticket OWNER TO postgres;

--
-- Name: ticket_pnr_number_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ticket_pnr_number_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ticket_pnr_number_seq OWNER TO postgres;

--
-- Name: ticket_pnr_number_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ticket_pnr_number_seq OWNED BY public.ticket.pnr_number;


--
-- Name: train; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.train (
    train_no integer NOT NULL,
    train_name character varying(45) NOT NULL,
    arrival_time time without time zone NOT NULL,
    departure_time time without time zone NOT NULL,
    src character varying NOT NULL,
    dest character varying NOT NULL
);


ALTER TABLE public.train OWNER TO postgres;

--
-- Name: trains_view; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.trains_view AS
 SELECT train.train_name,
    train.src,
    train.dest,
    train.arrival_time,
    train.departure_time,
    schedule.date_of_departure,
    schedule.date_of_arrival
   FROM public.train,
    public.schedule
  WHERE (train.train_no = schedule.train_no)
  ORDER BY schedule.date_of_departure;


ALTER TABLE public.trains_view OWNER TO postgres;

--
-- Name: user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."user" (
    user_id integer NOT NULL,
    password character varying(45) NOT NULL,
    first_name character varying(45) NOT NULL,
    last_name character varying(45),
    gender character varying(45) NOT NULL,
    age integer NOT NULL,
    email character varying(45),
    phone_no character varying(20) NOT NULL,
    address text
);


ALTER TABLE public."user" OWNER TO postgres;

--
-- Name: booking pnr_number; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.booking ALTER COLUMN pnr_number SET DEFAULT nextval('public.booking_pnr_number_seq'::regclass);


--
-- Name: passengers passenger_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.passengers ALTER COLUMN passenger_id SET DEFAULT nextval('public.passengers_passenger_id_seq'::regclass);


--
-- Name: ticket pnr_number; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket ALTER COLUMN pnr_number SET DEFAULT nextval('public.ticket_pnr_number_seq'::regclass);


--
-- Data for Name: availability; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.availability (s_no, seat_no, class, available_arr) FROM stdin;
\.
COPY public.availability (s_no, seat_no, class, available_arr) FROM '$$PATH$$/3393.dat';

--
-- Data for Name: booking; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.booking (booked_by, train_no, pnr_number, booking_time, date_of_departure) FROM stdin;
\.
COPY public.booking (booked_by, train_no, pnr_number, booking_time, date_of_departure) FROM '$$PATH$$/3394.dat';

--
-- Data for Name: passengers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.passengers (passenger_id, first_name, last_name, gender, age) FROM stdin;
\.
COPY public.passengers (passenger_id, first_name, last_name, gender, age) FROM '$$PATH$$/3396.dat';

--
-- Data for Name: route; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.route (train_no, "order", station_name) FROM stdin;
\.
COPY public.route (train_no, "order", station_name) FROM '$$PATH$$/3398.dat';

--
-- Data for Name: schedule; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.schedule (train_no, schedule_no, date_of_departure, date_of_arrival) FROM stdin;
\.
COPY public.schedule (train_no, schedule_no, date_of_departure, date_of_arrival) FROM '$$PATH$$/3399.dat';

--
-- Data for Name: ticket; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ticket (passenger_id, passenger_class, fare, seat_no, reservation_status, pnr_number, category, src, dest) FROM stdin;
\.
COPY public.ticket (passenger_id, passenger_class, fare, seat_no, reservation_status, pnr_number, category, src, dest) FROM '$$PATH$$/3400.dat';

--
-- Data for Name: train; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.train (train_no, train_name, arrival_time, departure_time, src, dest) FROM stdin;
\.
COPY public.train (train_no, train_name, arrival_time, departure_time, src, dest) FROM '$$PATH$$/3402.dat';

--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."user" (user_id, password, first_name, last_name, gender, age, email, phone_no, address) FROM stdin;
\.
COPY public."user" (user_id, password, first_name, last_name, gender, age, email, phone_no, address) FROM '$$PATH$$/3403.dat';

--
-- Name: booking_pnr_number_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.booking_pnr_number_seq', 29, true);


--
-- Name: passengers_passenger_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.passengers_passenger_id_seq', 80, true);


--
-- Name: ticket_pnr_number_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ticket_pnr_number_seq', 10, true);


--
-- Name: user age_check; Type: CHECK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE public."user"
    ADD CONSTRAINT age_check CHECK ((age > 0)) NOT VALID;


--
-- Name: booking booking_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.booking
    ADD CONSTRAINT booking_pkey PRIMARY KEY (pnr_number);


--
-- Name: ticket category_check; Type: CHECK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE public.ticket
    ADD CONSTRAINT category_check CHECK (((category)::text = ANY (ARRAY[('General'::character varying)::text, ('Tatkal'::character varying)::text, ('Ladies'::character varying)::text, ('Senior'::character varying)::text]))) NOT VALID;


--
-- Name: ticket class_check; Type: CHECK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE public.ticket
    ADD CONSTRAINT class_check CHECK (((passenger_class)::text = ANY (ARRAY[('AC'::character varying)::text, ('Sleeper'::character varying)::text]))) NOT VALID;


--
-- Name: availability class_check; Type: CHECK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE public.availability
    ADD CONSTRAINT class_check CHECK (((class)::text = ANY (ARRAY[('Sleeper'::character varying)::text, ('AC'::character varying)::text]))) NOT VALID;


--
-- Name: ticket fare_check; Type: CHECK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE public.ticket
    ADD CONSTRAINT fare_check CHECK ((fare > 0)) NOT VALID;


--
-- Name: user gender_check; Type: CHECK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE public."user"
    ADD CONSTRAINT gender_check CHECK (((gender)::text = ANY (ARRAY[('Male'::character varying)::text, ('Female'::character varying)::text, ('Other'::character varying)::text]))) NOT VALID;


--
-- Name: route order_check; Type: CHECK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE public.route
    ADD CONSTRAINT order_check CHECK (("order" > 0)) NOT VALID;


--
-- Name: passengers passengers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.passengers
    ADD CONSTRAINT passengers_pkey PRIMARY KEY (passenger_id);


--
-- Name: ticket reservation_check; Type: CHECK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE public.ticket
    ADD CONSTRAINT reservation_check CHECK (((reservation_status)::text = ANY (ARRAY[('Confirmed'::character varying)::text, ('Waiting List'::character varying)::text]))) NOT VALID;


--
-- Name: route route_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.route
    ADD CONSTRAINT route_pkey PRIMARY KEY (train_no, "order");


--
-- Name: schedule schedule_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule
    ADD CONSTRAINT schedule_pkey PRIMARY KEY (schedule_no);


--
-- Name: ticket seat_check; Type: CHECK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE public.ticket
    ADD CONSTRAINT seat_check CHECK (((seat_no >= 0) AND (seat_no <= 10))) NOT VALID;


--
-- Name: availability seat_check; Type: CHECK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE public.availability
    ADD CONSTRAINT seat_check CHECK (((seat_no >= 0) AND (seat_no <= 10))) NOT VALID;


--
-- Name: train train_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.train
    ADD CONSTRAINT train_pkey PRIMARY KEY (train_no);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (user_id);


--
-- Name: hash_station; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX hash_station ON public.route USING hash (station_name);


--
-- Name: ticket avail_seat; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER avail_seat BEFORE INSERT ON public.ticket FOR EACH ROW EXECUTE FUNCTION public.set_avail();


--
-- Name: ticket delete_entry; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER delete_entry AFTER DELETE ON public.ticket FOR EACH ROW EXECUTE FUNCTION public.delete_passenger();


--
-- Name: ticket free_seat; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER free_seat AFTER DELETE ON public.ticket FOR EACH ROW EXECUTE FUNCTION public.free_avail();


--
-- Name: booking bookedby; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.booking
    ADD CONSTRAINT bookedby FOREIGN KEY (booked_by) REFERENCES public."user"(user_id) NOT VALID;


--
-- Name: ticket pass; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket
    ADD CONSTRAINT pass FOREIGN KEY (passenger_id) REFERENCES public.passengers(passenger_id) NOT VALID;


--
-- Name: availability s_in; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.availability
    ADD CONSTRAINT s_in FOREIGN KEY (s_no) REFERENCES public.schedule(schedule_no);


--
-- Name: booking train; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.booking
    ADD CONSTRAINT train FOREIGN KEY (train_no) REFERENCES public.train(train_no) NOT VALID;


--
-- Name: route train_in; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.route
    ADD CONSTRAINT train_in FOREIGN KEY (train_no) REFERENCES public.train(train_no);


--
-- Name: schedule train_no_in; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule
    ADD CONSTRAINT train_no_in FOREIGN KEY (train_no) REFERENCES public.train(train_no);


--
-- PostgreSQL database dump complete
--

